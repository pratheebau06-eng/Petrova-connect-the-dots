from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

tasks = {
    "software_engineer": {
        "question": "Write a Python function to check if a number is even.",
        "answer": "def is_even"
    },
    "designer": {
        "question": "What color combination improves readability?",
        "answer": "contrast"
    }
}

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/get_task", methods=["POST"])
def get_task():
    role = request.json["role"]
    return jsonify(tasks.get(role, {}))

@app.route("/evaluate", methods=["POST"])
def evaluate():
    user_answer = request.json["answer"].lower()
    correct_answer = request.json["correct"].lower()

    if correct_answer in user_answer:
        result = "Good job! You seem fit for this role."
    else:
        result = "You may need improvement. Try exploring other roles."

    return jsonify({"result": result})

if __name__ == "__main__":
    app.run(debug=True)
